import React from 'react'
import './App.css'
import {BrowserRouter, Route, Routes } from 'react-router-dom'
import SignUpForm from './components/SignUpForm'
import LoginForm from './components/LoginForm'
import Dashboard from './components/Dashboard/Dashboard'
import Profile from "./components/Profile";
import "react-image-crop/dist/ReactCrop.css";
import HeaderLogo from './assets/image-2LogoImg.png'
import lock from './assets/FramelockPng.png'

function LoginRouter() {
  return (
  
    
  )
}

export default LoginRouter