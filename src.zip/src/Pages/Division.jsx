import React, { useState } from 'react';
import CustomButton from '../components/MyComponents/CustomButton';
import MyTable from '../components/Division/MyTable';
import { NavLink, Outlet } from 'react-router-dom';




function division() {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };
  
  
  return (
    <>
      
     
     <Outlet/>



      
      <div  className="flex justify-between px-10 py-5 border-b-[1px] border-gray-300">
      <div style={{ position: 'relative', display: 'inline-block' }}>
      <input
            type="text"
            placeholder="Search by index"
            style={{
              padding: '8px 50px 8px 10px',
              borderRadius: '4px',
              border: '1px solid #ccc',
              width: '400px',
              height: '50px',
              boxSizing: 'border-box',
              fontSize: '16px',
            }}
            value={searchQuery}
            onChange={handleSearchChange}
          />
            <i className="fa-solid fa-magnifying-glass" style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', color: 'gray' }}></i>
        </div>
        <NavLink to={'create'} > <CustomButton buttonText={'Create New Division'} width={'176px'} height={'50px'} fontSize={'16px'} padding={'10px 30px 10px 30px'}  /></NavLink>
       
     </div>
      <div className='pt-10 px-8'>
        <MyTable searchQuery={searchQuery} />
      </div>
     
            
          
 
    </>
  )
}

export default division