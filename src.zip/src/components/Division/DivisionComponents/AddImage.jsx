import React, { useRef, useState } from 'react';
import uploadSvg from '../../../assets/vectors/cardIcon/upload.svg';
import { ErrorMessage, Field } from 'formik';

function AddImage() {

  const MIN_DIMENSION = 150;

  
  const [selectedImage, setSelectedImage] = useState(null); // State to store selected image
  const uploadBtn = useRef(null);
  const [img, setImg] = useState(false);
  const [imgErr, setImgErr] = useState(false);

  const handleBtn = () => {
    uploadBtn.current.click();
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      


      reader.addEventListener("load", () => {
        const imageElement = new Image();
        const imageUrl = reader.result?.toString() || "";
        imageElement.src = imageUrl;
  
        imageElement.addEventListener("load", (e) => {
          
          const { naturalWidth, naturalHeight } = e.currentTarget;
          if (naturalWidth < 300 || naturalHeight < 300) {
            setImgErr(true);
            return setSelectedImage("");
          }
        });
        setSelectedImage(imageUrl);
        setImgErr(false);
      })



      // reader.onload = (event) => {
      //   setSelectedImage(event.target.result); // Set selected image to state
      // };
      reader.readAsDataURL(file);
      setImg(true)
    }
  };

  return (
    <>
        <Field
                name='mediaFile'
                id='mediaFile'
                className='hidden'
                type='file'
                ref={uploadBtn}
                accept='image/*'
                onChange={handleImageChange}
              />
      <div className='text-xl mb-3'>Add Image</div>
      <div className='w-[590px] h-[270px] border-2 border-gray-300 rounded-lg flex flex-col justify-center items-center'>
       
          {selectedImage ? (
            <img src={selectedImage} alt="Selected Image" style={{ maxWidth: '100%', maxHeight: '100%' }} />
          ) : (
            <>
               <div className='p-3 rounded-lg' style={{ backgroundColor: '#ffa007' }}>
                <img src={uploadSvg} alt="Upload Icon" />
                
              </div>
              <div className='p-4 text-center'>Drag and Drop here<br />or</div>
              <button
                type='button'
          className='px-6 py-1 text-center border-solid border-2 rounded-xl hover:bg-gray-100'
          style={{ borderColor: '#ffa007' }}
                onClick={() => { document.getElementById('mediaFile').click() }}
        >
          Upload
        </button>
            
              
                
                </>
          )}
        
        
      </div>
      {imgErr && <div className="text-red-600">Image must be at least 300 x 300 pixels.</div>}
      {!img && <ErrorMessage name='mediaFile' component="div" className="text-red-600" />}
      
    </>
  );
}

export default AddImage;
