import Sidenav from "../components/Dashboard/Sidenav";

function DashboardLayout() {
  return (
    <>
      <Sidenav />
    </>
  );
}

export default DashboardLayout;
