import React from "react";
import ListedWarehouse from "../components/Division/Warehouse/ListedWarehouse";

function Warehouse() {
  return (
    <div>
      <ListedWarehouse />
    </div>
  );
}

export default Warehouse;
